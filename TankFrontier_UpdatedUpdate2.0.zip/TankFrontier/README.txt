TANK FRONTIER - PYTHON / PYGAME MVC PROJECT

FILES
- main.py       Starts Pygame and runs the game loop.
- model.py      Stores tanks, health, score, terrain, obstacles, turns,
                projectile state, collision checks, damage, and enemy AI.
- view.py       Draws the menu, battlefield, tanks, health bars, projectiles,
                explosions, and end screens.
- controller.py Handles keyboard input and sends actions to the Model.

REQUIREMENTS
- Python 3
- Pygame

INSTALL
    python -m pip install pygame

RUN
Open a terminal in this folder and run:
    python main.py

CONTROLS
- ENTER: Start / restart
- LEFT / RIGHT: Adjust player aim angle
- UP / DOWN: Adjust player firing power
- SPACE: Fire
- ESC: Return to menu (or quit from menu)

GAME RULES
- Both tanks stay in their positions.
- Player and enemy take alternating turns.
- Each tank starts with 100 HP.
- Shell impacts create arcade-style explosions.
- Nearby tanks and destructible trees/rocks can take damage.
- Explosions leave visible craters in the ground.
- The player earns points for damaging/destroying enemy and obstacles.

MVC
- Model: game data and rules; it does not draw graphics.
- View: draws the game; it does not decide damage or turns.
- Controller: reads input and tells the Model what action to perform.

NOTE
Projectile motion and damage are simplified fictional arcade mechanics
for a classroom game, not a real-world physics or weapons simulator.


BALANCE / SKY UPDATE
- Player shells have increased arcade speed/range.
- Enemy AI randomly selects a 5%, 10%, 15%, or 20% accuracy level each turn.
  Successful rolls aim close to the baseline; unsuccessful rolls add a larger
  random angle/power adjustment. Actual hits can still vary with terrain.
- Sky transitions through sunrise, noon, sunset, and night.
- Each sky phase lasts 80 seconds (1 minute 20 seconds).
