import pygame


class GameController:
    def handle_events(self, model):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                model.running = False

            if event.type == pygame.KEYDOWN:
                if model.state == "menu":
                    if event.key == pygame.K_RETURN:
                        model.reset()
                        model.state = "playing"
                    elif event.key == pygame.K_ESCAPE:
                        model.running = False

                elif model.state == "playing":
                    if event.key == pygame.K_ESCAPE:
                        model.state = "menu"

                    elif model.turn == "player" and not model.projectile and not model.explosion:
                        if event.key == pygame.K_LEFT:
                            model.adjust_aim(angle_change=2)
                        elif event.key == pygame.K_RIGHT:
                            model.adjust_aim(angle_change=-2)
                        elif event.key == pygame.K_UP:
                            model.adjust_aim(power_change=3)
                        elif event.key == pygame.K_DOWN:
                            model.adjust_aim(power_change=-3)
                        elif event.key == pygame.K_SPACE:
                            model.fire(model.player)

                elif model.state in ("victory", "game_over"):
                    if event.key == pygame.K_RETURN:
                        model.reset()
                        model.state = "playing"
                    elif event.key == pygame.K_ESCAPE:
                        model.state = "menu"
