import pygame

from model import GameModel
from view import GameView
from controller import GameController


def main():
    pygame.init()

    model = GameModel()
    view = GameView()
    controller = GameController()

    while model.running:
        dt = view.clock.tick(60) / 1000.0

        controller.handle_events(model)
        model.update(dt)
        view.update(dt)
        view.draw(model)

    pygame.quit()


if __name__ == "__main__":
    main()
